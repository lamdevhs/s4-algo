# coding: utf8

# Bayard Nathanael

# Ex 3

# Solution gloutonne :

# à chaque étape, on choisit de prendre la plus petite
# valeur restante et de la mettre dans le package
# qui contient la plus petite valeur. on peut prouver par
# récurrence forte (en fait, récurrence d'ordre 2)
# que c'est toujours le package que l'on n'a
# pas choisit la fois précédente:

# soit p(n) la somme des valeurs du package1 après l'étape n
# et idem pour q(n) et package2.
# donc, p(0) = 0, q(0) = 0. le premier choix est évident:
# on prend la plus petite valeur v(1) de la liste des valeurs,
# et on le met dans p (choix arbitraire entre p et q).
# d'où p(1) = v(1), q(1) = 0, et p(1) >= q(1).
# à l'étape 2, on choisit logiquement de prendre la deuxième
# plus petite valeur restante, v(2) >= v(1), et de la mettre dans
# q, pour minimiser l'écart.
# d'où p(2) = v(1), q(2) = v(2) et p(2) <= q(2).

# supposons qu'on ait:
# p(n-1) <= q(n-1).
# soit alors x := q(n-1) - p(n-1) >= 0
# on suppose qu'on choisit
# p(n) := p(n-1) + v(n)
# q(n) := q(n-1)
# et par hypothèse, p(n) >= q(n)
# donc on peut en déduire:
# q(n) = p(n-1) + x <= p(n) = p(n-1) + v(n)
# d'où x <= v(n) (***)
# on ajoute v(n+1) >= v(n) à
# q(n) pour obtenir q(n+1). on a alors:
# p(n+1) = p(n) = p(n-1) + v(n)
# q(n+1) = q(n) + v(n+1) = q(n-1) + v(n+1) = p(n-1) + x + v(n+1)
# d'où q(n+1) >= p(n+1)
# on ajoute alors v(n+2) >= v(n+1) à
# p(n+1) pour obtenir p(n+2), et alors:
# p(n+2) = p(n+1) + v(n+2) = p(n) + v(n+2) = p(n-1) + v(n) + v(n+2)
# q(n+2) = q(n+1) = p(n-1) + x + v(n+1)
# or on a x <= v(n) (cf ***) et v(n+2) >= v(n+1)
# donc finalement, on prouve bien qu'avec ces
# hypothèses et cet algorithme, on obtient une fois de plus
# p(n+2) >= q(n+2).

# en d'autres termes, l'algorithme alternera bien le
# signe de la différence entre p(n) et q(n) à chaque
# étape n.

def glutton(values):
  package1 = []
  package2 = []
  thisOne = package1
  nextOne = package2
  values.sort()
  for value in values:
    thisOne.append(value)
    thisOne, nextOne = nextOne, thisOne
  return (package1, package2)

def difference(package1, package2):
  return abs(sum(package1) - sum(package2))


# ---------------------------------------


# by construction, package1 and package2 are already
# sorted in an ascending fashion
def validSolution(package1, package2, bestSoFar):
  if sum(package1) > sum(package2) or len(package1) < len(package2):
    return False # deadend: to avoid duplicates
  if difference(package1, package2) > bestSoFar:
    return False # deadend: this is not one of the best
  return True

def backtracker(values, amounts, valueIndex, result, package1, package2, bestSoFar):
  if valueIndex == len(values):
    if validSolution(package1, package2, bestSoFar):
      hereBest = difference(package1, package2)
      if hereBest < bestSoFar:
        # if the current solution is strictly better
        # we discard all previously found solutions
        result[:] = []
        bestSoFar = hereBest
      result.append((package1[:], package2[:]))
      #print result
      # ^ either way we append the valid solution we found
      # we probably don't need to copy those lists, but
      # better safe than sorry...
    return bestSoFar
    # ^ to propagate the current value of bestSoFar
    # to the other paths that we go through next

  else:
    value = values[valueIndex]
    maxAmount = amounts[valueIndex]
    # for each different value: we gotta choose
    # how many times we gonna put it in package1
    # we'll put the remaining amount in package2
    # necessarily
    for amount1 in range(0, maxAmount + 1):
      amount2 = maxAmount - amount1
      bestSoFar = backtracker(
        values, amounts, valueIndex + 1, result,
        package1[:] + [value]*amount1,
        package2[:] + [value]*amount2, bestSoFar)
    return bestSoFar
    # ^ to propagate the current value of bestSoFar
    # to the other paths that we go through next
    
def group(values):
  values = sorted(values)
  previousValue = None
  previousValueAmount = 0
  uniqueValues = []
  amountsOfEach = []
  for value in values:
    if previousValue == value:
      previousValueAmount += 1
    else:
      if previousValue != None:
        uniqueValues.append(previousValue)
        amountsOfEach.append(previousValueAmount)
      previousValue = value
      previousValueAmount = 1
  if previousValue != None:
    uniqueValues.append(previousValue)
    amountsOfEach.append(previousValueAmount)
  return (uniqueValues, amountsOfEach)

def launch_backtracker(values):
  Lsol = []
  plusInfinity = float("inf")
  # ^ we need to be sure any difference in the
  # packages in any solution we can find
  # will be better (smaller) than none
  (uniqueValues, amountsOfEach) = group(values)
  backtracker(
    values = uniqueValues,
    amounts = amountsOfEach,
    valueIndex = 0,
    result = Lsol,
    package1 = [],
    package2 =[],
    bestSoFar = plusInfinity)
  return Lsol

def ex3(L):
  print "------------------------"
  print "Liste :", L
  print "-----"
  g = glutton(L)
  print "solution glouttone :", g
  print "différence :",
  print     difference(*g)
  bt = launch_backtracker(L)
  print "-----"
  print "solutions par backtracking :", bt
  if len(bt) != 0:
    print "différence :",
    print     difference(*bt[0])
  print

ex3([1,6,3,6,20,20,10])
ex3([1,2,50,3])