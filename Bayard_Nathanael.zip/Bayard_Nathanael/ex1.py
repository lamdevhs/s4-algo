# coding: utf8

# Bayard Nathanael

# Ex 1

# on suppose pieces trié dans l'ordre
# croissant.
# cette solution gloutonne
# en theta(N) ne marchera
# pas pour un système de pièces non complet...
def renduDeMonnaie(S, pieces):
  L = []
  pieces.reverse()
  for p in pieces:
    n = S // p
    S = S - n*p
    L += [p]*n
  return L

print renduDeMonnaie(42, [2, 5,10])