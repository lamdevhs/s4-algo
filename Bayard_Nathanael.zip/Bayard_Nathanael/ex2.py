# coding: utf8

# Bayard Nathanael

# Ex 2

# n -> B(n)
# 0 -> 1
# 1 -> -1
# 2 -> B(1)B(1) + (-1)^1 = 1 - 1 = 0
# 3 -> B(1)B(2) + (-1) + B(2)B(1) + 1 = 0
# 4 -> B(1)B(3) + B(2)B(2) + B(3)B(2) -1 = -1
# 5 -> B(1)B(4) + B(2)B(3) + B(3)B(2) + B(4)B(1)
#       = 1 + 0 + 0 + 1 = 2


def B(n):
  L = [0, -1] + [42]*(n+1 -2)
  for i in range(2, n + 1):
    value = 0
    for k in range(1, i):
      value += L[k]*L[i-k] + (-1)**k
    L[i] = value
  return L[n]

for n in range(6):
  print B(n)